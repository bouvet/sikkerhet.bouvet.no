# Bouvet — World Cup 2026 Guessing Game · Design System

A **dark-mode** design system for the *World Cup 2026 Guessing Game*, built on the **Bouvet** brand. Bouvet ASA is a Nordic consultancy specialising in IT and digital communication, headquartered in Oslo and operating across Norway, Sweden and internationally. This project takes Bouvet's (light-mode) brand identity and extends it into a cohesive dark-mode system suited to an energetic, sporty prediction game.

> **Note on derivation.** The source brand book ships as a light-mode identity (navy ink on white/cream surfaces with vivid accents). There is no official dark-mode spec. Everything in the `Dark-mode surfaces` and `Semantic accents` layers is *derived* from the real brand hues — the navy becomes the base, the vivid accents are tuned to pop on dark. The raw brand palette is preserved verbatim in `colors_and_type.css` under "RAW BRAND PALETTE".

---

## Sources

- **`uploads/Bouvet brand.pdf`** — the Bouvet brand guidelines (28 pages, vector artwork; text outlined to paths). Colors, typeface and letterform construction were sampled directly from this file.
  - Typeface specimen extracted to `assets/inter-specimen.png`
  - Letterform construction grid extracted to `assets/letterform-construction.png`
- Public reference: Bouvet ASA — `www.bouvet.no`. The wordmark is a typeface logotype (public-domain as a typographic mark).

The brand book pages could **not** be rasterised (pathological vector glyph paths hang pdf.js), so layouts were inferred from the extracted color/type/letterform data rather than full-page screenshots.

---

## What's here (index)

| Path | What it is |
|---|---|
| `README.md` | This file — context, content & visual foundations, iconography |
| `colors_and_type.css` | All design tokens: raw brand palette, dark-mode surfaces, text, semantic accents, radii, shadows, spacing, type scale |
| `SKILL.md` | Agent-Skill manifest so this system can be used in Claude Code |
| `assets/` | Logos: `wc-logo-white.svg` / `wc-logo-navy.svg` (the in-app **World Cup 26** tournament lockup), `logo-white.svg` / `logo-navy.svg` (Bouvet parent wordmark), `app-icon.svg`, plus extracted brand specimens |
| `preview/` | Design-system cards (swatches, type specimens, tokens, components) shown in the Design System tab |
| `ui_kits/world-cup-game/` | High-fidelity, click-through recreation of the guessing-game app (dark mode) |

---

## CONTENT FUNDAMENTALS

The Bouvet voice is **plain, warm, confident and human** — Nordic-direct, never corporate-fluffy. For the guessing game it leans a little more **playful and energetic** without losing the calm clarity of the parent brand.

- **Person:** Speaks to the player as **"you"**; the product/team is **"we"**. ("Your picks are locked.", "We'll tally points right after the final whistle.")
- **Tone:** Encouraging and low-pressure. Wins are celebrated plainly ("Nice — 3 of 4 correct"), misses are softened ("So close. Better luck in the quarter-finals.").
- **Casing:** **Sentence case** everywhere — buttons, headings, menu items. ("Make your pick", not "Make Your Pick"). The only uppercase is the small **eyebrow/label** style (tracked-out, 11px) used for section kickers and stat labels (e.g. `GROUP STAGE`, `YOUR RANK`).
- **Length:** Short. Headlines are 2–6 words; helper text one sentence. Numbers and verbs carry the message.
- **Punctuation:** Minimal. No exclamation-mark spam — at most one per moment of genuine celebration.
- **Emoji:** **Not used** in the parent brand and avoided here. Energy comes from color, motion and the bright accents — not emoji. (Sport/flag glyphs may appear as *data*, e.g. country flags, but never as decorative emoji in UI copy.)
- **Numbers:** Always tabular (`font-variant-numeric: tabular-nums`) so scores, timers and standings don't jitter. Points framed positively ("+15 pts").

**Examples**
- Empty state: *"No picks yet. The group stage kicks off Thursday — get your guesses in."*
- CTA: *"Lock in picks"* / *"See the leaderboard"* / *"Edit my bracket"*
- Result toast: *"Full time. You banked 22 points this round."*
- Eyebrow: `ROUND OF 16` · `YOUR STREAK` · `MATCHDAY 3`

---

## VISUAL FOUNDATIONS

**Overall vibe.** Confident Nordic modernism turned up for sport: a deep navy field, crisp white type, and a small set of electric accents used sparingly but boldly. Lots of negative space, strong typographic hierarchy, flat surfaces with subtle elevation. Nothing skeuomorphic, nothing fussy.

**Color.**
- The brand rests on a **three-color core: navy · cream · green.** Navy `#11133C` is the ground; **cream `#F9EAD4`** is the warm primary, used for **everything interactive and identity-bearing** — primary CTAs, selected/active states (tabs, chips, the chosen score), the points pill, your-row highlight, and section eyebrows. **Mint-green `#79FE9D`** is reserved for **semantic meaning only**: a correct/exact result, positive movement (▲ up), a qualified team, and live-confirmation. Green never appears as mere decoration — if it's green, it *means* something.
- The dark UI is built as an **elevation ladder** from `--bg-0` (`#07081C`, app backdrop) up to `--bg-5` (`#2C3180`, pressed/high) — surfaces get *lighter* as they rise, never grey.
- Other accents are the real brand hues, each carrying meaning: **raspberry `#EB1D4B`** (live/urgent/wrong/kickoff), **coral `#F9A86F`** (points, streaks), **electric blue** (`#5B7CFF`, informational), **lavender `#A27BFA`** (bonus/power-ups).
- Accents are **point colors**, not fills — one dominant accent per screen region, and each accent earns its place by *meaning* (never decoration). Cream is the only color used purely for brand/interaction.
- Text is cool off-white: `--fg-1` pure white for headings, `--fg-2` brand sky `#C3D5E1` for body, `--fg-3` `#8B95C9` muted. Never pure mid-grey.

**Typography.** **Inter** throughout — it is the official Bouvet typeface (confirmed from the brand book specimen). Display/headlines use Inter at **800 weight** with tight negative tracking (-0.025 to -0.03em) for a punchy, condensed-feeling headline. Body is regular 400 at 1.55 line-height. Scores and stats use tabular figures. There is no secondary or serif face.

**Spacing & layout.** 4px base grid (`--s-1`…`--s-9`). Generous gutters; content sits in calm columns. Use fl ex/grid with `gap` — never inline-flow spacing. Fixed elements: a top app bar and (on mobile) a bottom tab bar; main content scrolls between them.

**Backgrounds.** Flat navy fields — **no gradients as decoration** (a single very-subtle radial glow behind a hero number is the maximum). No photographic backgrounds, no noise/grain, no repeating texture. Energy is delivered by accent color and bold type on calm navy.

**Corner radii.** **None — Bouvet uses sharp, square corners, with no exceptions.** Every shape — cards, buttons, inputs, chips, badges, tiles, avatars and country badges — is radius `0`. There are no circles or pills in the UI. The radius tokens (`--r-xs`…`--r-pill`) are all set to `0` so the rule cascades through every component. The only round shapes are genuinely circular badges — country badges and avatars — which are circles by design, not rounded rectangles.

**Cards.** Surface `--bg-2`/`--bg-3`, **square corners (radius 0)**, a 1px hairline border (`--border-1`), `--shadow-2` ambient shadow. No colored left-border accents. Emphasis cards (live match, your rank) may use an accent **glow** (`--glow-accent` / `--glow-hot`) instead of a heavier shadow.

**Borders & dividers.** Hairlines are translucent cool-white (`--border-1/2/3`) so they read on any elevation. Dividers are the same.

**Transparency & blur.** Used sparingly: sticky bars and modals sit on a `backdrop-filter: blur` over a semi-opaque navy (`rgba(14,16,51,0.8)`). Tinted accent fills (`--accent-quiet`, `--hot-quiet`, …) are low-alpha washes for selected/active states.

**Elevation/shadow system.** Two layers: (1) ambient dark shadows (`--shadow-1/2/3`) for depth, (2) accent **glows** for live/active emphasis. Pressed states drop to a higher surface (`--bg-5`) and lose their shadow.

**Animation.** Quick and crisp — `120–220ms`, `ease-out` for entrances, `ease-in-out` for state changes. Subtle scale on press (`scale(0.97)`), accent glow ramps in for "live". No bounce, no long parallax, no infinite decorative loops. Respect `prefers-reduced-motion`.

**Hover / press states.**
- Hover: surface lifts one elevation step (`--bg-3 → --bg-4`) and/or border strengthens (`--border-1 → --border-2`); the primary button brightens to white (`--btn-primary-bg-hover`).
- Press: scale down to `0.97`, drop to `--btn-primary-bg-press` / `--bg-5`.
- Focus: 2px cream ring (`box-shadow: 0 0 0 2px var(--cream-quiet)` + cream border), never a default browser outline.

**Imagery vibe.** Minimal. Country flags and player/club imagery appear as crisp **square** badges. No moody photo treatments; the palette already carries the energy.

---

## ICONOGRAPHY

The Bouvet brand book does **not** ship a proprietary icon font — its visual language is carried by type, color and the wordmark, not a bespoke icon set. The extracted illustrations in the book are simple flat pictograms (e.g. a pointer/cursor hand) rather than a systematic UI icon library.

**Decision for this system:** use **[Lucide](https://lucide.dev)** (loaded from CDN) as the UI icon set. Lucide's even **2px stroke**, rounded line caps and geometric construction match Inter's clean, modern feel and the brand's flat, unfussy aesthetic. This is a **substitution** — flag it to the user if a proprietary Bouvet icon set surfaces later.

- **Style:** outline / stroke icons, 2px, `currentColor` so they inherit text color and accents.
- **Sizing:** 20px in dense UI, 24px default, 28–32px for primary nav.
- **Emoji:** not used in UI chrome. Country flags (a legitimate sport data element) are rendered as **square** flag badges, not emoji glyphs.
- **Unicode glyphs:** avoided as icons — always use a real Lucide icon.
- **Logo/marks:** the **in-app brand mark** is `assets/wc-logo-white.svg` / `wc-logo-navy.svg` — an *original* "World Cup 26" tournament lockup (a simple football mark + wordmark). This is **original artwork**: the official FIFA World Cup logo is a protected trademark and is not reproduced. The Bouvet parent wordmark (`logo-white.svg` / `logo-navy.svg`, Inter 800, tight tracking) appears as a "powered by" endorsement. `app-icon.svg` is the square app mark (green "B" on navy).

CDN: `<script src="https://unpkg.com/lucide@latest"></script>` then `lucide.createIcons()`.
